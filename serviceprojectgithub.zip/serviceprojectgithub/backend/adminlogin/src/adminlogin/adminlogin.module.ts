/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AdminloginController } from './adminlogin.controller';
import { AdminloginService } from './adminlogin.service';
import { AdminLoginSchema } from './adminlogin.model'; // Import the schema

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'AdminLogin', schema: AdminLoginSchema },
    ]),
  ],
  controllers: [AdminloginController],
  providers: [AdminloginService],
})
export class AdminloginModule {}

