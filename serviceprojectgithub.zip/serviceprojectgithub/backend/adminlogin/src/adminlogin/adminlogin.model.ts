/* eslint-disable prettier/prettier */

import * as mongoose from 'mongoose';

export const AdminLoginSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },
  password: {
    type: String,
    required: true,
    minlength: 8,
  },
});

export interface AdminLogin extends mongoose.Document {
  id: string;
  name: string;
  password: string;
}
