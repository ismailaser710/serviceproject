/* eslint-disable prettier/prettier */
import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  Patch,
  BadRequestException,
} from '@nestjs/common';
import { AdminloginService } from './adminlogin.service';
import type { AdminLogin } from './adminlogin.model';

@Controller('adminlogin')
export class AdminloginController {
  constructor(private readonly adminloginService: AdminloginService) {}

  // ----------------- POST Admin -----------------
  @Post('post')
  async postAdmin(
    @Body() postAdminDto: Partial<AdminLogin>,
  ): Promise<AdminLogin> {
    const { name, password } = postAdminDto;

    // Required fields
    if (!name || !password) {
      throw new BadRequestException('Name and password are required');
    }

    // Check if name already exists
    const existingAdmin = await this.adminloginService.findByName(name);
    if (existingAdmin) {
      throw new BadRequestException('Admin name already exists');
    }

    // Password complexity
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)/;
    if (!passwordRegex.test(password)) {
      throw new BadRequestException(
        'Password must contain at least one uppercase letter and one number',
      );
    }

    // Password length
    if (password.length < 8) {
      throw new BadRequestException(
        'Password must be at least 8 characters long',
      );
    }

    return this.adminloginService.post(postAdminDto as AdminLogin);
  }

  // ----------------- GET All Admins -----------------
  @Get('getall')
  async getAllAdmins(): Promise<AdminLogin[]> {
    return this.adminloginService.findAll();
  }

  // ----------------- GET One Admin -----------------
  @Get('getone/:id')
  async getAdminById(@Param('id') id: string): Promise<AdminLogin> {
    return this.adminloginService.findOne(id);
  }

  // ----------------- PUT Admin (FULL UPDATE) -----------------
  @Put('put/:id')
  async putAdmin(
    @Param('id') id: string,
    @Body() putAdminDto: Partial<AdminLogin>,
  ): Promise<AdminLogin> {
    const { name, password } = putAdminDto;

    if (!name || !password) {
      throw new BadRequestException(
        'Send all required fields: name, password',
      );
    }

    // Ensure name is unique
    const existingAdmin = await this.adminloginService.findByName(name);
    if (existingAdmin && existingAdmin._id.toString() !== id) {
      throw new BadRequestException(
        'Name is already used by another admin',
      );
    }

    // Password validation
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)/;
    if (!passwordRegex.test(password)) {
      throw new BadRequestException(
        'Password must contain at least one uppercase letter and one number',
      );
    }

    if (password.length < 8) {
      throw new BadRequestException(
        'Password must be at least 8 characters long',
      );
    }

    return this.adminloginService.put(id, putAdminDto as AdminLogin);
  }

  // ----------------- PATCH Admin (PARTIAL UPDATE) -----------------
  @Patch('patch/:id')
  async patchAdmin(
    @Param('id') id: string,
    @Body() updates: Partial<AdminLogin>,
  ): Promise<any> {
    if (
      (updates.name === undefined || updates.name.trim() === '') &&
      (updates.password === undefined ||
        updates.password === '' ||
        updates.password.trim() === '')
    ) {
      throw new BadRequestException(
        'At least one of name or password must be provided and not empty',
      );
    }

    // Name validation
    if (updates.name !== undefined) {
      const existingAdmin = await this.adminloginService.findByName(
        updates.name,
      );
      if (existingAdmin && existingAdmin._id.toString() !== id) {
        throw new BadRequestException(
          'Name is already registered by another admin',
        );
      }
    }

    // Password validation
    if (updates.password !== undefined) {
      const passwordRegex = /^(?=.*[A-Z])(?=.*\d)/;
      if (!passwordRegex.test(updates.password)) {
        throw new BadRequestException(
          'Password must contain at least one uppercase letter and one number',
        );
      }

      if (updates.password.length < 8) {
        throw new BadRequestException(
          'Password must be at least 8 characters long',
        );
      }
    }

    return this.adminloginService.patch(id, updates);
  }

  // ----------------- DELETE Admin -----------------
  @Delete('delete/:id')
  async deleteAdmin(@Param('id') id: string): Promise<any> {
    return this.adminloginService.delete(id);
  }
}



