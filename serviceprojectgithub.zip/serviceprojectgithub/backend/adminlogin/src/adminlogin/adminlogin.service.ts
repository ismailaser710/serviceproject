/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { AdminLogin } from './adminlogin.model';

@Injectable()
export class AdminloginService {
  constructor(
    @InjectModel('AdminLogin')
    private readonly adminLoginModel: Model<AdminLogin>,
  ) {}

  // ----------------- POST Admin -----------------
  async post(admin: AdminLogin): Promise<AdminLogin> {
    const newAdmin = new this.adminLoginModel(admin);
    return await newAdmin.save();
  }

  // ----------------- FIND ALL Admins -----------------
  async findAll(): Promise<AdminLogin[]> {
    return await this.adminLoginModel.find().exec();
  }

  // ----------------- FIND Admin BY ID -----------------
  async findOne(id: string): Promise<AdminLogin> {
    const admin = await this.adminLoginModel.findById(id).exec();
    if (!admin) {
      throw new Error('Admin not found');
    }
    return admin;
  }

  // ----------------- FIND Admin BY NAME -----------------
  async findByName(name: string): Promise<AdminLogin | null> {
    return await this.adminLoginModel.findOne({ name }).exec();
  }

  // ----------------- PUT Admin (FULL UPDATE) -----------------
  async put(
    id: string,
    admin: Partial<AdminLogin>,
  ): Promise<AdminLogin> {
    const updatedAdmin = await this.adminLoginModel
      .findByIdAndUpdate(id, admin, { new: true })
      .exec();

    if (!updatedAdmin) {
      throw new Error('Admin not found');
    }

    return updatedAdmin;
  }

  // ----------------- PATCH Admin (Partial Update) -----------------
  async patch(
    id: string,
    updates: Partial<AdminLogin>,
  ): Promise<AdminLogin> {
    const updatedAdmin = await this.adminLoginModel
      .findByIdAndUpdate(id, updates, { new: true })
      .exec();

    if (!updatedAdmin) {
      throw new Error('Admin not found');
    }

    return updatedAdmin;
  }

  // ----------------- DELETE Admin -----------------
  async delete(id: string): Promise<any> {
    const result = await this.adminLoginModel
      .deleteOne({ _id: id })
      .exec();

    if (result.deletedCount === 0) {
      throw new Error('Admin not found');
    }

    return { message: 'Admin deleted successfully' };
  }
}




