/* eslint-disable prettier/prettier */
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Get port from environment variable or default to 3001
  const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3001;

  await app.listen(PORT);
  console.log(`AdminLogin service running on port ${PORT}`);
}
bootstrap();

