/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { AdminloginController } from './adminlogin/adminlogin.controller';
import { AdminloginService } from './adminlogin/adminlogin.service';
import { AdminLoginSchema } from './adminlogin/adminlogin.model';

@Module({
  imports: [
    // ---------- Load .env globally ----------
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),

    // ---------- MongoDB Connection ----------
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const dbUri = configService.get<string>('DB');
        if (!dbUri) {
          throw new Error('DB connection string is missing in .env');
        }
        return {
          uri: dbUri,       // ONLY this is needed in Mongoose 7+
          autoIndex: true,  // optional: automatically build indexes
          maxPoolSize: 10,  // optional: max connections
          serverSelectionTimeoutMS: 5000, // optional: connection timeout
        };
      },
    }),

    // ---------- AdminLogin Schema ----------
    MongooseModule.forFeature([
      { name: 'AdminLogin', schema: AdminLoginSchema },
    ]),
  ],

  controllers: [AdminloginController],
  providers: [AdminloginService],
})
export class AppModule {}


