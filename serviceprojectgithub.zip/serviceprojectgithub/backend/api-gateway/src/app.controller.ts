/* eslint-disable prettier/prettier */
import { Controller, Get, Post, Put, Patch, Delete, Param, Body } from '@nestjs/common';
import { AppService } from './app.service';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  // ----------------- ADMINLOGIN -----------------
  @Get('adminlogins')
  getAllAdmins() {
    return this.appService.getAllAdmins();
  }

  @Get('adminlogins/:id')
  getAdminById(@Param('id') id: string) {
    return this.appService.getAdminById(id);
  }

  @Post('adminlogins')
  postAdmin(@Body() body: any) {
    return this.appService.postAdmin(body);
  }

  @Put('adminlogins/:id')
  putAdmin(@Param('id') id: string, @Body() body: any) {
    return this.appService.putAdmin(id, body);
  }

  @Patch('adminlogins/:id')
  patchAdmin(@Param('id') id: string, @Body() body: any) {
    return this.appService.patchAdmin(id, body);
  }

  @Delete('adminlogins/:id')
  deleteAdmin(@Param('id') id: string) {
    return this.appService.deleteAdmin(id);
  }

  // ----------------- USERSIGNUP -----------------
  @Get('usersignups')
  getAllUsers() {
    return this.appService.getAllUsers();
  }

  @Get('usersignups/:id')
  getUserById(@Param('id') id: string) {
    return this.appService.getUserById(id);
  }

  @Post('usersignups')
  postUser(@Body() body: any) {
    return this.appService.postUser(body);
  }

  @Put('usersignups/:id')
  putUser(@Param('id') id: string, @Body() body: any) {
    return this.appService.putUser(id, body);
  }

  @Patch('usersignups/:id')
  patchUser(@Param('id') id: string, @Body() body: any) {
    return this.appService.patchUser(id, body);
  }

  @Delete('usersignups/:id')
  deleteUser(@Param('id') id: string) {
    return this.appService.deleteUser(id);
  }

  // ----------------- PRODUCT -----------------
  @Get('products')
  getAllProducts() {
    return this.appService.getAllProducts();
  }

  @Get('products/:id')
  getProductById(@Param('id') id: string) {
    return this.appService.getProductById(id);
  }

  @Post('products')
  postProduct(@Body() body: any) {
    return this.appService.postProduct(body);
  }

  @Put('products/:id')
  putProduct(@Param('id') id: string, @Body() body: any) {
    return this.appService.putProduct(id, body);
  }

  @Patch('products/:id')
  patchProduct(@Param('id') id: string, @Body() body: any) {
    return this.appService.patchProduct(id, body);
  }

  @Delete('products/:id')
  deleteProduct(@Param('id') id: string) {
    return this.appService.deleteProduct(id);
  }

  // ----------------- ORDER -----------------
  @Get('orders')
  getAllOrders() {
    return this.appService.getAllOrders();
  }

  @Get('orders/:id')
  getOrderById(@Param('id') id: string) {
    return this.appService.getOrderById(id);
  }

  @Post('orders')
  postOrder(@Body() body: any) {
    return this.appService.postOrder(body);
  }

  @Put('orders/:id')
  putOrder(@Param('id') id: string, @Body() body: any) {
    return this.appService.putOrder(id, body);
  }

  @Patch('orders/:id')
  patchOrder(@Param('id') id: string, @Body() body: any) {
    return this.appService.patchOrder(id, body);
  }

  @Delete('orders/:id')
  deleteOrder(@Param('id') id: string) {
    return this.appService.deleteOrder(id);
  }
}


