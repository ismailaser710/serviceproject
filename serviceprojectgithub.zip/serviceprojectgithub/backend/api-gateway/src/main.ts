/* eslint-disable prettier/prettier */
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Enable CORS for all origins
  // Or restrict to your frontend URL like 'http://localhost:5173'
  app.enableCors({
    origin: 'http://localhost:5173',
    methods: 'GET,HEAD,PUT,PATCH,POST,DELETE,OPTIONS',
    credentials: true,
  });

  const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;
  await app.listen(PORT);
  console.log(`API Gateway running on port ${PORT}`);
}
bootstrap();
