/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

@Injectable()
export class AppService {
  constructor(private readonly httpService: HttpService) {}

  // ----------------- ADMINLOGIN MICROSERVICE -----------------
  getAllAdmins() {
    return firstValueFrom(
      this.httpService.get('http://localhost:3001/adminlogin/getall')
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  getAdminById(id: string) {
    return firstValueFrom(
      this.httpService.get(`http://localhost:3001/adminlogin/getone/${id}`)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  postAdmin(data: any) {
    return firstValueFrom(
      this.httpService.post('http://localhost:3001/adminlogin/post', data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  putAdmin(id: string, data: any) {
    return firstValueFrom(
      this.httpService.put(`http://localhost:3001/adminlogin/put/${id}`, data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  patchAdmin(id: string, data: any) {
    return firstValueFrom(
      this.httpService.patch(`http://localhost:3001/adminlogin/patch/${id}`, data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  deleteAdmin(id: string) {
    return firstValueFrom(
      this.httpService.delete(`http://localhost:3001/adminlogin/delete/${id}`, { data: { id } })
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  // ----------------- USERSIGNUP MICROSERVICE -----------------
  getAllUsers() {
    return firstValueFrom(
      this.httpService.get('http://localhost:3002/usersignup/getall')
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  getUserById(id: string) {
    return firstValueFrom(
      this.httpService.get(`http://localhost:3002/usersignup/getone/${id}`)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  postUser(data: any) {
    return firstValueFrom(
      this.httpService.post('http://localhost:3002/usersignup/post', data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  putUser(id: string, data: any) {
    return firstValueFrom(
      this.httpService.put(`http://localhost:3002/usersignup/put/${id}`, data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  patchUser(id: string, data: any) {
    return firstValueFrom(
      this.httpService.patch(`http://localhost:3002/usersignup/patch/${id}`, data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  deleteUser(id: string) {
    return firstValueFrom(
      this.httpService.delete(`http://localhost:3002/usersignup/delete/${id}`, { data: { id } })
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  // ----------------- PRODUCT MICROSERVICE -----------------
  getAllProducts() {
    return firstValueFrom(
      this.httpService.get('http://localhost:3003/product/getall')
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  getProductById(id: string) {
    return firstValueFrom(
      this.httpService.get(`http://localhost:3003/product/getone/${id}`)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  postProduct(data: any) {
    return firstValueFrom(
      this.httpService.post('http://localhost:3003/product/post', data, { headers: { 'Content-Type': 'application/json' } })
    )
      .then(res => {
        // Return the created product object
        return res.data.product || res.data;
      })
      .catch(err => {
        console.error('postProduct error:', err.response?.data);
        return err.response?.data || { message: 'Unknown error' };
      });
  }

  putProduct(id: string, data: any) {
    return firstValueFrom(
      this.httpService.put(`http://localhost:3003/product/put/${id}`, data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  patchProduct(id: string, data: any) {
    return firstValueFrom(
      this.httpService.patch(`http://localhost:3003/product/patch/${id}`, data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  deleteProduct(id: string) {
    return firstValueFrom(
      this.httpService.delete(`http://localhost:3003/product/delete/${id}`, { data: { id } })
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  // ----------------- ORDER MICROSERVICE -----------------
  getAllOrders() {
    return firstValueFrom(
      this.httpService.get('http://localhost:3004/order/getall')
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  getOrderById(id: string) {
    return firstValueFrom(
      this.httpService.get(`http://localhost:3004/order/getone/${id}`)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  postOrder(data: any) {
    return firstValueFrom(
      this.httpService.post('http://localhost:3004/order/post', data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  putOrder(id: string, data: any) {
    return firstValueFrom(
      this.httpService.put(`http://localhost:3004/order/put/${id}`, data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  patchOrder(id: string, data: any) {
    return firstValueFrom(
      this.httpService.patch(`http://localhost:3004/order/patch/${id}`, data)
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }

  deleteOrder(id: string) {
    return firstValueFrom(
      this.httpService.delete(`http://localhost:3004/order/delete/${id}`, { data: { id } })
    )
      .then(res => res.data)
      .catch(err => err.response?.data || { message: 'Unknown error' });
  }
}