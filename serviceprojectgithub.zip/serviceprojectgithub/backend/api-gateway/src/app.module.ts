/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { HttpModule as NestHttpModule } from '@nestjs/axios';

@Module({
  imports: [
    NestHttpModule, // allows HTTP requests to microservices
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}


