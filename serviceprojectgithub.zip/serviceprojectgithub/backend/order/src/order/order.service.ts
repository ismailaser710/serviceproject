/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Order } from './order.model';

@Injectable()
export class OrderService {
  constructor(
    @InjectModel('Order')
    private readonly orderModel: Model<Order>,
  ) {}

  // ----------------- POST Order -----------------
  async post(order: Order): Promise<Order> {
    const newOrder = new this.orderModel(order);
    return await newOrder.save();
  }

  // ----------------- FIND ALL Orders -----------------
  async findAll(): Promise<Order[]> {
    return await this.orderModel.find().exec();
  }

  // ----------------- FIND Order BY ID -----------------
  async findOne(id: string): Promise<Order> {
    const order = await this.orderModel.findById(id).exec();
    if (!order) {
      throw new Error('Order not found');
    }
    return order;
  }

  // ----------------- PUT Order (FULL UPDATE) -----------------
  async put(
    id: string,
    order: Partial<Order>,
  ): Promise<Order> {
    const updatedOrder = await this.orderModel
      .findByIdAndUpdate(id, order, { new: true })
      .exec();

    if (!updatedOrder) {
      throw new Error('Order not found');
    }

    return updatedOrder;
  }

  // ----------------- PATCH Order (Partial Update) -----------------
  async patch(
    id: string,
    updates: Partial<Order>,
  ): Promise<Order> {
    const updatedOrder = await this.orderModel
      .findByIdAndUpdate(id, updates, { new: true })
      .exec();

    if (!updatedOrder) {
      throw new Error('Order not found');
    }

    return updatedOrder;
  }

  // ----------------- DELETE Order -----------------
  async delete(id: string): Promise<any> {
    const result = await this.orderModel
      .deleteOne({ _id: id })
      .exec();

    if (result.deletedCount === 0) {
      throw new Error('Order not found');
    }

    return { message: 'Order deleted successfully' };
  }
}

