/* eslint-disable prettier/prettier */

import * as mongoose from 'mongoose';

export const OrderSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true,
  },
  email: {
    type: String,
    required: true,
    trim: true,
  },
  phonenumber: {
    type: String,
    required: true,
    trim: true,
  },
  items: {
    type: Number,
    required: true,
    min: 1,
  },
  total: {
    type: Number,
    required: true,
    min: 1,
  },
});

export interface Order extends mongoose.Document {
  id: string;
  name: string;
  email: string;
  phonenumber: string;
  items: number;
  total: number;
}
