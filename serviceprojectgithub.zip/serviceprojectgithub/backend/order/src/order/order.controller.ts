/* eslint-disable prettier/prettier */
import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  Patch,
  BadRequestException,
} from '@nestjs/common';
import { OrderService } from './order.service';
import type { Order } from './order.model';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

@Controller('order')
export class OrderController {
  constructor(
    private readonly orderService: OrderService,
    private readonly httpService: HttpService,
  ) {}

  // ----------------- POST Order -----------------
  @Post('post')
  async postOrder(@Body() body: Partial<Order>): Promise<Order> {
    const { name, email, phonenumber, items, total } = body;

    if (
      !name ||
      !email ||
      !phonenumber ||
      items === undefined ||
      total === undefined
    ) {
      throw new BadRequestException(
        'Send all required fields: name, email, phonenumber, items, total',
      );
    }

    if (items < 1) {
      throw new BadRequestException('Items must be at least 1');
    }

    if (total <= 0) {
      throw new BadRequestException('Total must be greater than 0');
    }

    const phoneRegex = /^\d{11}$/;
    if (!phoneRegex.test(phonenumber)) {
      throw new BadRequestException(
        'Phonenumber must be exactly 11 digits',
      );
    }

    const usersResponse = await firstValueFrom(
      this.httpService.get('http://localhost:3002/usersignup/getall'),
    );
    const users = usersResponse.data || [];
    const emailExists = users.some(
      (user: any) => user.email === email,
    );
    if (!emailExists) {
      throw new BadRequestException(
        'Email does not exist in the usersignups database',
      );
    }

    return this.orderService.post(body as Order);
  }

  // ----------------- GET All Orders -----------------
  @Get('getall')
  async getAllOrders(): Promise<Order[]> {
    return this.orderService.findAll();
  }

  // ----------------- GET One Order -----------------
  @Get('getone/:id')
  async getOrderById(@Param('id') id: string): Promise<Order> {
    return this.orderService.findOne(id);
  }

  // ----------------- PUT Order (FULL UPDATE) -----------------
  @Put('put/:id')
  async putOrder(
    @Param('id') id: string,
    @Body() body: Partial<Order>,
  ): Promise<Order> {
    const { name, email, phonenumber, items, total } = body;

    if (
      !name ||
      !email ||
      !phonenumber ||
      items === undefined ||
      total === undefined
    ) {
      throw new BadRequestException(
        'Send all required fields: name, email, phonenumber, items, total',
      );
    }

    if (items < 1) {
      throw new BadRequestException('Items must be at least 1');
    }

    if (total <= 0) {
      throw new BadRequestException('Total must be greater than 0');
    }

    const phoneRegex = /^\d{11}$/;
    if (!phoneRegex.test(phonenumber)) {
      throw new BadRequestException(
        'Phonenumber must be exactly 11 digits',
      );
    }

    const usersResponse = await firstValueFrom(
      this.httpService.get('http://localhost:3002/usersignup/getall'),
    );
    const users = usersResponse.data || [];
    const emailExists = users.some(
      (user: any) => user.email === email,
    );
    if (!emailExists) {
      throw new BadRequestException(
        'Email does not exist in the usersignups database',
      );
    }

    return this.orderService.put(id, body);
  }

  // ----------------- PATCH Order (PARTIAL UPDATE) -----------------
  @Patch('patch/:id')
  async patchOrder(
    @Param('id') id: string,
    @Body() updates: Partial<Order>,
  ): Promise<any> {
    // Loop through provided fields and validate individually
    for (const [key, value] of Object.entries(updates)) {
      switch (key) {
        case 'name':
        case 'email':
        case 'phonenumber':
          if (
            value === undefined ||
            value === null ||
            (typeof value === 'string' && value.trim() === '')
          ) {
            throw new BadRequestException(`${key} cannot be null or empty`);
          }
          break;
        case 'items':
        case 'total':
          // Keep validation as-is below, outside switch
          break;
        default:
          throw new BadRequestException(`Invalid field: ${key}`);
      }
    }

    // Items and total checks remain as-is
    if (updates.items !== undefined && updates.items < 1) {
      throw new BadRequestException('Items must be at least 1');
    }

    if (updates.total !== undefined && updates.total <= 0) {
      throw new BadRequestException('Total must be greater than 0');
    }

    // Validate phonenumber if provided
    if (updates.phonenumber !== undefined) {
      const phoneRegex = /^\d{11}$/;
      if (!phoneRegex.test(updates.phonenumber)) {
        throw new BadRequestException(
          'Phonenumber must be exactly 11 digits',
        );
      }
    }

    // Validate email if provided (case-sensitive)
    if (updates.email !== undefined) {
      const usersResponse = await firstValueFrom(
        this.httpService.get('http://localhost:3002/usersignup/getall'),
      );
      const users = usersResponse.data || [];
      const emailExists = users.some((user: any) => user.email === updates.email);
      if (!emailExists) {
        throw new BadRequestException(
          'Email does not exist in the usersignups database',
        );
      }
    }

    return this.orderService.patch(id, updates);
  }

  // ----------------- DELETE Order -----------------
  @Delete('delete/:id')
  async deleteOrder(@Param('id') id: string): Promise<any> {
    return this.orderService.delete(id);
  }
}

