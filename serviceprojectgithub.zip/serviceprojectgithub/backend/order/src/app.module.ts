/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { OrderModule } from './order/order.module';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const dbUri = configService.get<string>('DB');
        if (!dbUri) throw new Error('DB connection string is missing in .env');
        return { uri: dbUri, autoIndex: true, maxPoolSize: 10, serverSelectionTimeoutMS: 5000 };
      },
    }),
    OrderModule, // <-- import the module that has HttpModule
  ],
  controllers: [],
  providers: [],
})
export class AppModule {}



