/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { ProductController } from './product/product.controller';
import { ProductService } from './product/product.service';
import { ProductSchema } from './product/product.model';

@Module({
  imports: [
    // ---------- Load .env globally ----------
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),

    // ---------- MongoDB Connection ----------
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const dbUri = configService.get<string>('DB');
        if (!dbUri) {
          throw new Error('DB connection string is missing in .env');
        }
        return {
          uri: dbUri,                // MongoDB URI from .env
          autoIndex: true,           // optional: automatically build indexes
          maxPoolSize: 10,           // optional: max connections
          serverSelectionTimeoutMS: 5000, // optional: connection timeout
        };
      },
    }),

    // ---------- Product Schema ----------
    MongooseModule.forFeature([
      { name: 'Product', schema: ProductSchema },
    ]),
  ],

  controllers: [ProductController],
  providers: [ProductService],
})
export class AppModule {}

