/* eslint-disable prettier/prettier */
import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  Patch,
  BadRequestException,
} from '@nestjs/common';
import { ProductService } from './product.service';
import type { Product } from './product.model';

@Controller('product')
export class ProductController {
  constructor(private readonly productService: ProductService) {}

  // ----------------- POST Product -----------------
  @Post('post')
  async postProduct(
    @Body() postProductDto: Partial<Product>,
  ): Promise<Product> {
    const { name, description, price, quantity, category, location } =
      postProductDto;

    // Required fields check
    if (
      !name ||
      !description ||
      price === undefined || price === null || price === 0 ||
      !quantity && quantity !== 0 || // quantity can be 0
      !category ||
      !location
    ) {
      throw new BadRequestException(
        'Send all required fields: name, description, price, quantity, category, location',
      );
    }

    // Check if product name already exists
    const existingProduct = await this.productService.findByName(name);
    if (existingProduct) {
      throw new BadRequestException('Product with this name already exists');
    }

    // Description length validation
    if (description.length < 20) {
      throw new BadRequestException(
        'Description must be more than 20 characters',
      );
    }

    // Price validation
    if (typeof price !== 'number' || Number.isNaN(price) || price < 5) {
      throw new BadRequestException(
        'Price must be a number and greater than or equal to 5',
      );
    }

    // Quantity validation
    if (typeof quantity !== 'number' || Number.isNaN(quantity) || quantity < 0) {
      throw new BadRequestException(
        'Quantity must be a number and greater than or equal to 0',
      );
    }

    return this.productService.post(postProductDto as Product);
  }

  // ----------------- PUT Product (FULL UPDATE) -----------------
  @Put('put/:id')
  async putProduct(
    @Param('id') id: string,
    @Body() putProductDto: Partial<Product>,
  ): Promise<Product> {
    const { name, description, price, quantity, category, location } =
      putProductDto;

    // Required fields check
    if (
      !name ||
      !description ||
      price === undefined || price === null || price === 0 ||
      !quantity && quantity !== 0 || // quantity can be 0
      !category ||
      !location
    ) {
      throw new BadRequestException(
        'Send all required fields: name, description, price, quantity, category, location',
      );
    }

    // Check if name is unique
    const existingProduct = await this.productService.findByName(name);
    if (existingProduct && existingProduct._id.toString() !== id) {
      throw new BadRequestException(
        'Another product with this name already exists',
      );
    }

    // Description length validation
    if (description.length < 20) {
      throw new BadRequestException(
        'Description must be more than 20 characters',
      );
    }

    // Price validation
    if (typeof price !== 'number' || Number.isNaN(price) || price < 5) {
      throw new BadRequestException(
        'Price must be a number and greater than or equal to 5',
      );
    }

    // Quantity validation
    if (typeof quantity !== 'number' || Number.isNaN(quantity) || quantity < 0) {
      throw new BadRequestException(
        'Quantity must be a number and greater than or equal to 0',
      );
    }

    return this.productService.put(id, putProductDto as Product);
  }

  // ----------------- PATCH Product (PARTIAL UPDATE) -----------------
  @Patch('patch/:id')
  async patchProduct(
    @Param('id') id: string,
    @Body() updates: Partial<Product>,
  ): Promise<any> {
    // Loop through provided fields and validate individually
    for (const [key, value] of Object.entries(updates)) {
      switch (key) {
        case 'name':
        case 'description':
        case 'category':
        case 'location':
        case 'price': // treat price like string fields for null/empty/0
          if (
            value === undefined ||
            value === null ||
            (typeof value === 'string' && value.trim() === '') ||
            (key === 'price' && value === 0)
          ) {
            throw new BadRequestException(
              `${key} cannot be null, empty, or zero`,
            );
          }

          // Name uniqueness check immediately after null/empty check
          if (key === 'name') {
            const existingProduct = await this.productService.findByName(
              value.toString(),
            );
            if (existingProduct && existingProduct._id.toString() !== id) {
              throw new BadRequestException(
                'Another product with this name already exists',
              );
            }
          }

          // Additional validations
          if (key === 'description' && value.toString().length < 20) {
            throw new BadRequestException(
              'Description must be more than 20 characters',
            );
          }

          if (key === 'price' && (typeof value !== 'number' || Number.isNaN(value) || value < 5)) {
            throw new BadRequestException(
              'Price must be a number and greater than or equal to 5',
            );
          }
          break;

        case 'quantity':
          if (typeof value !== 'number' || Number.isNaN(value) || value < 0) {
            throw new BadRequestException(
              'Quantity must be a number and greater than or equal to 0',
            );
          }
          break;
      }
    }

    return this.productService.patch(id, updates);
  }

  // ----------------- GET All Products -----------------
  @Get('getall')
  async getAllProducts(): Promise<Product[]> {
    return this.productService.findAll();
  }

  // ----------------- GET One Product -----------------
  @Get('getone/:id')
  async getProductById(@Param('id') id: string): Promise<Product> {
    return this.productService.findOne(id);
  }

  // ----------------- DELETE Product -----------------
  @Delete('delete/:id')
  async deleteProduct(@Param('id') id: string): Promise<any> {
    return this.productService.delete(id);
  }
}




