/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Product } from './product.model';

@Injectable()
export class ProductService {
  constructor(
    @InjectModel('Product')
    private readonly productModel: Model<Product>,
  ) {}

  // ----------------- POST Product -----------------
  async post(product: Product): Promise<Product> {
    const newProduct = new this.productModel(product);
    return await newProduct.save();
  }

  // ----------------- FIND ALL Products -----------------
  async findAll(): Promise<Product[]> {
    return await this.productModel.find().exec();
  }

  // ----------------- FIND Product BY ID -----------------
  async findOne(id: string): Promise<Product> {
    const product = await this.productModel.findById(id).exec();
    if (!product) {
      throw new Error('Product not found');
    }
    return product;
  }

  // ----------------- FIND Product BY NAME -----------------
  async findByName(name: string): Promise<Product | null> {
    return await this.productModel.findOne({ name }).exec();
  }

  // ----------------- PUT Product (FULL UPDATE) -----------------
  async put(
    id: string,
    product: Partial<Product>,
  ): Promise<Product> {
    const updatedProduct = await this.productModel
      .findByIdAndUpdate(id, product, { new: true })
      .exec();

    if (!updatedProduct) {
      throw new Error('Product not found');
    }

    return updatedProduct;
  }

  // ----------------- PATCH Product (Partial Update) -----------------
  async patch(
    id: string,
    updates: Partial<Product>,
  ): Promise<Product> {
    const updatedProduct = await this.productModel
      .findByIdAndUpdate(id, updates, { new: true })
      .exec();

    if (!updatedProduct) {
      throw new Error('Product not found');
    }

    return updatedProduct;
  }

  // ----------------- DELETE Product -----------------
  async delete(id: string): Promise<any> {
    const result = await this.productModel
      .deleteOne({ _id: id })
      .exec();

    if (result.deletedCount === 0) {
      throw new Error('Product not found');
    }

    return { message: 'Product deleted successfully' };
  }
}

