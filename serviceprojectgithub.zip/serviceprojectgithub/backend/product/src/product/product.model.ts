/* eslint-disable prettier/prettier */
import * as mongoose from 'mongoose';

export const ProductSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    trim: true,
  },
  description: {
    type: String,
    required: true,
    minlength: 20,
    trim: true,
  },
  price: {
    type: Number,
    required: true,
    min: 5,
  },
  quantity: {
    type: Number,
    required: true,
    min: 0,
  },
  category: {
    type: String,
    required: true,
    trim: true,
  },
  location: {
    type: String,
    required: true,
    trim: true,
  },
});

export interface Product extends mongoose.Document {
  id: string;
  name: string;
  description: string;
  price: number;
  quantity: number;
  category: string;
  location: string;
}
