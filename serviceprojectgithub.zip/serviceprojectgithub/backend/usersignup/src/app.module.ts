/* eslint-disable prettier/prettier */
import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { MongooseModule } from '@nestjs/mongoose';
import { UsersignupController } from './usersignup/usersignup.controller';
import { UsersignupService } from './usersignup/usersignup.service';
import { UserSignUpSchema } from './usersignup/usersignup.model';

@Module({
  imports: [
    // ---------- Load .env globally ----------
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath: '.env',
    }),

    // ---------- MongoDB Connection ----------
    MongooseModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: (configService: ConfigService) => {
        const dbUri = configService.get<string>('DB');
        if (!dbUri) {
          throw new Error('DB connection string is missing in .env');
        }
        return {
          uri: dbUri,                // ONLY this is needed in Mongoose 7+
          autoIndex: true,            // optional: automatically build indexes
          maxPoolSize: 10,            // optional: max connections
          serverSelectionTimeoutMS: 5000, // optional: connection timeout
        };
      },
    }),

    // ---------- UserSignUp Schema ----------
    MongooseModule.forFeature([
      { name: 'UserSignUp', schema: UserSignUpSchema },
    ]),
  ],

  controllers: [UsersignupController],
  providers: [UsersignupService],
})
export class AppModule {}

