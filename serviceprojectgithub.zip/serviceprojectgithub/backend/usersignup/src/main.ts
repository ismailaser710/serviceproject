/* eslint-disable prettier/prettier */
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Get port from environment variable or default to 3002
  const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3002;

  await app.listen(PORT);
  console.log(`UserSignUp service running on port ${PORT}`);
}
bootstrap();

