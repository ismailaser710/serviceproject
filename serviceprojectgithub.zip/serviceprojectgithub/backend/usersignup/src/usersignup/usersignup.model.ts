/* eslint-disable prettier/prettier */

import * as mongoose from 'mongoose';

export const UserSignUpSchema = new mongoose.Schema({
  firstname: {
    type: String,
    required: true,
  },
  lastname: {
    type: String,
    required: true,
  },
  email: {
    type: String,
    required: true,
    unique: true,
  },
  phonenumber: {
    type: String,
    required: true,
    maxlength: 11,
  },
  password: {
    type: String,
    required: true,
    minlength: 8,
  },
  confirmpassword: {
    type: String,
    required: true,
    minlength: 8,
  },
});

export interface UserSignUp extends mongoose.Document {
  id: string;
  firstname: string;
  lastname: string;
  email: string;
  phonenumber: string;
  password: string;
  confirmpassword: string;
}
