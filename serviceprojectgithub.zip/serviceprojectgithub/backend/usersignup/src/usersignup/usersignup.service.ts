/* eslint-disable prettier/prettier */
import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { UserSignUp } from './usersignup.model';

@Injectable()
export class UsersignupService {
  constructor(
    @InjectModel('UserSignUp')
    private readonly userSignUpModel: Model<UserSignUp>,
  ) {}

  // ----------------- POST UserSignUp -----------------
  async post(user: UserSignUp): Promise<UserSignUp> {
    const newUser = new this.userSignUpModel(user);
    return await newUser.save();
  }

  // ----------------- FIND ALL UserSignUps -----------------
  async findAll(): Promise<UserSignUp[]> {
    return await this.userSignUpModel.find().exec();
  }

  // ----------------- FIND UserSignUp BY ID -----------------
  async findOne(id: string): Promise<UserSignUp> {
    const user = await this.userSignUpModel.findById(id).exec();
    if (!user) {
      throw new Error('User not found');
    }
    return user;
  }

  // ----------------- FIND UserSignUp BY EMAIL -----------------
  async findByEmail(email: string): Promise<UserSignUp | null> {
    return await this.userSignUpModel.findOne({ email }).exec();
  }

  // ----------------- PUT UserSignUp (FULL UPDATE) -----------------
  async put(
    id: string,
    user: Partial<UserSignUp>,
  ): Promise<UserSignUp> {
    const updatedUser = await this.userSignUpModel
      .findByIdAndUpdate(id, user, { new: true })
      .exec();

    if (!updatedUser) {
      throw new Error('User not found');
    }

    return updatedUser;
  }

  // ----------------- PATCH UserSignUp (Partial Update) -----------------
  async patch(
    id: string,
    updates: Partial<UserSignUp>,
  ): Promise<UserSignUp> {
    const updatedUser = await this.userSignUpModel
      .findByIdAndUpdate(id, updates, { new: true })
      .exec();

    if (!updatedUser) {
      throw new Error('User not found');
    }

    return updatedUser;
  }

  // ----------------- DELETE UserSignUp -----------------
  async delete(id: string): Promise<any> {
    const result = await this.userSignUpModel
      .deleteOne({ _id: id })
      .exec();

    if (result.deletedCount === 0) {
      throw new Error('User not found');
    }

    return { message: 'User deleted successfully' };
  }
}

