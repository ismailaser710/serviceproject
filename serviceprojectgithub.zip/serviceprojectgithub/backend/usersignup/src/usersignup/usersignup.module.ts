/* eslint-disable prettier/prettier */

import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { UsersignupController } from './usersignup.controller';
import { UsersignupService } from './usersignup.service';
import { UserSignUpSchema } from './usersignup.model';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'UserSignUp', schema: UserSignUpSchema },
    ]),
  ],
  controllers: [UsersignupController],
  providers: [UsersignupService],
})
export class UsersignupModule {}

