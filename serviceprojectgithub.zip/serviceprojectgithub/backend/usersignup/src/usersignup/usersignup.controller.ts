/* eslint-disable prettier/prettier */
import {
  Controller,
  Get,
  Post,
  Body,
  Param,
  Put,
  Delete,
  Patch,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import { UsersignupService } from './usersignup.service';
import type { UserSignUp } from './usersignup.model';

@Controller('usersignup')
export class UsersignupController {
  constructor(private readonly usersignupService: UsersignupService) {}

  // ----------------- POST UserSignUp -----------------
  @Post('post')
  async postUserSignUp(
    @Body() postUserDto: Partial<UserSignUp>,
  ): Promise<UserSignUp> {
    const {
      firstname,
      lastname,
      email,
      phonenumber,
      password,
      confirmpassword,
    } = postUserDto;

    if (
      !firstname ||
      !lastname ||
      !email ||
      !phonenumber ||
      !password ||
      !confirmpassword
    ) {
      throw new BadRequestException(
        'Send all required fields: firstname, lastname, email, phonenumber, password, confirmpassword',
      );
    }

    // Email must contain exactly one @
    const atCount = (email.match(/@/g) || []).length;
    if (atCount !== 1) {
      throw new BadRequestException(
        'Email must contain exactly one @ character',
      );
    }

    // Email uniqueness
    const existingUser = await this.usersignupService.findByEmail(email);
    if (existingUser) {
      throw new BadRequestException('Email is already registered');
    }

    // Phone number length
    if (phonenumber.length !== 11) {
      throw new BadRequestException(
        'Phone number must be exactly 11 characters',
      );
    }

    // -------- Password Validation --------
    // Password complexity
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)/;
    if (!passwordRegex.test(password)) {
      throw new BadRequestException(
        'Password must contain at least one uppercase letter and one number',
      );
    }

    // Password length
    if (password.length < 8) {
      throw new BadRequestException('Password must exceed 8 characters');
    }

    // Password match
    if (password !== confirmpassword) {
      throw new BadRequestException(
        'Password and confirm password must match',
      );
    }

    return this.usersignupService.post(postUserDto as UserSignUp);
  }

  // ----------------- GET All UserSignUps -----------------
  @Get('getall')
  async getAllUserSignUps(): Promise<UserSignUp[]> {
    return this.usersignupService.findAll();
  }

  // ----------------- GET One UserSignUp -----------------
  @Get('getone/:id')
  async getUserSignUpById(@Param('id') id: string): Promise<UserSignUp> {
    const user = await this.usersignupService.findOne(id);
    if (!user) {
      throw new NotFoundException('User not found');
    }
    return user;
  }

  // ----------------- PUT UserSignUp (FULL UPDATE) -----------------
  @Put('put/:id')
  async putUserSignUp(
    @Param('id') id: string,
    @Body() putUserDto: Partial<UserSignUp>,
  ): Promise<UserSignUp> {
    const {
      firstname,
      lastname,
      email,
      phonenumber,
      password,
      confirmpassword,
    } = putUserDto;

    if (
      !firstname ||
      !lastname ||
      !email ||
      !phonenumber ||
      !password ||
      !confirmpassword
    ) {
      throw new BadRequestException(
        'Send all required fields: firstname, lastname, email, phonenumber, password, confirmpassword',
      );
    }

    const atCount = (email.match(/@/g) || []).length;
    if (atCount !== 1) {
      throw new BadRequestException(
        'Email must contain exactly one @ character',
      );
    }

    const existingUser = await this.usersignupService.findByEmail(email);
    if (existingUser && existingUser._id.toString() !== id) {
      throw new BadRequestException(
        'Email is already registered by another user',
      );
    }

    if (phonenumber.length !== 11) {
      throw new BadRequestException(
        'Phone number must be exactly 11 characters',
      );
    }

    // -------- Password Validation --------
    const passwordRegex = /^(?=.*[A-Z])(?=.*\d)/;
    if (!passwordRegex.test(password)) {
      throw new BadRequestException(
        'Password must contain at least one uppercase letter and one number',
      );
    }

    if (password.length < 8) {
      throw new BadRequestException('Password must exceed 8 characters');
    }

    if (password !== confirmpassword) {
      throw new BadRequestException(
        'Password and confirm password must match',
      );
    }

    const updatedUser = await this.usersignupService.put(
      id,
      putUserDto as UserSignUp,
    );

    if (!updatedUser) {
      throw new NotFoundException('User not found');
    }

    return updatedUser;
  }

  // ----------------- PATCH UserSignUp (PARTIAL UPDATE) -----------------
  @Patch('patch/:id')
  async patchUserSignUp(
    @Param('id') id: string,
    @Body() updates: Partial<UserSignUp>,
  ): Promise<any> {
    // Validate firstname, lastname, email, phonenumber
    if (updates.firstname !== undefined && updates.firstname.trim() === '') {
      throw new BadRequestException('Firstname cannot be null or empty');
    }
    if (updates.lastname !== undefined && updates.lastname.trim() === '') {
      throw new BadRequestException('Lastname cannot be null or empty');
    }
    if (updates.email !== undefined) {
      if (updates.email.trim() === '') {
        throw new BadRequestException('Email cannot be empty');
      }
      const atCount = (updates.email.match(/@/g) || []).length;
      if (atCount !== 1) {
        throw new BadRequestException(
          'Email must contain exactly one @ character',
        );
      }
      const existingUser = await this.usersignupService.findByEmail(
        updates.email,
      );
      if (existingUser && existingUser._id.toString() !== id) {
        throw new BadRequestException(
          'Email is already registered by another user',
        );
      }
    }
    if (updates.phonenumber !== undefined) {
      if (updates.phonenumber.trim() === '') {
        throw new BadRequestException('Phone number cannot be empty');
      }
      if (updates.phonenumber.length !== 11) {
        throw new BadRequestException(
          'Phone number must be exactly 11 characters',
        );
      }
    }

    // -------- Password & Confirm Password validation --------
    if (
      updates.password !== undefined ||
      updates.confirmpassword !== undefined
    ) {
      const password: string = updates.password ?? '';
      const confirmpassword: string = updates.confirmpassword ?? '';

      // Password complexity
      const passwordRegex = /^(?=.*[A-Z])(?=.*\d)/;
      if (!passwordRegex.test(password)) {
        throw new BadRequestException(
          'Password must contain at least one uppercase letter and one number',
        );
      }

      // Password length
      if (password.length < 8) {
        throw new BadRequestException('Password must exceed 8 characters');
      }

      // Password match
      if (password !== confirmpassword) {
        throw new BadRequestException(
          'Password and confirm password must match',
        );
      }
    }

    const result = await this.usersignupService.patch(id, updates);
    if (!result) {
      throw new NotFoundException('User not found');
    }

    return { message: 'User updated successfully', data: result };
  }

  // ----------------- DELETE UserSignUp -----------------
  @Delete('delete/:id')
  async deleteUserSignUp(@Param('id') id: string): Promise<any> {
    const result = await this.usersignupService.delete(id);
    if (!result) {
      throw new NotFoundException('User not found');
    }
    return { message: 'User deleted successfully' };
  }
}